# Aspireit Assignment

## Name : Riya Saifi

## email : 

## Project Structure

- `app/`: Contains the Flask application.
- `app/auth/`: Authentication-related routes and models.
- `app/main/`: Main application routes and models.
- `app/ml/`: Machine learning model integration.
- `app/templates/`: HTML templates.
- `app/static/`: Static files such as CSS.
- `tests/`: Test cases.
- `run.py`: Entry point to start the Flask application.

## API Endpoints

- **/auth/register (POST):** Register a new user.
- **/auth/login (POST):** User login.
- **/main/profile (GET, PUT):** Retrieve and update the user profile.
- **/main/buffer (POST):** Upload a buffer object.
- __/main/buffer/<buffer_id> (GET):__ Retrieve a buffer object.
- **/main/analyze (POST):** Analyze text data.

## Setup Instructions

1. Clone the repository.
2. Navigate to the project directory.
3. Create and activate a virtual environment:

```bash {"id":"01J7K8FKYS7MW21R12FK57GNB9"}
   python -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
```

## Install the dependencies:

```bash {"id":"01J7K8FKYS7MW21R12FMK0GAHR"}
pip install -r requirements.txt   

```

## Start the Flask application:

```bash {"id":"01J7K8FKYS7MW21R12FR8VZQA7"}
python run.py
```

## Running the Backend unit Tests

You can run the tests by executing the following command in your terminal:

```bash {"id":"01J7K8FKYS7MW21R12FSE142TS"}
python -m unittest discover tests
```

## Frontend (React):

## Install dependencies:

```bash {"id":"01J7K8FKYTPAVVSVKD12M8CTSV"}
npm install
```

## Start the React development server:

```bash {"id":"01J7K8FKYTPAVVSVKD160BMDWY"}
npm start
```




